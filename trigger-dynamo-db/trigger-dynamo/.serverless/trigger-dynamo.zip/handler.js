module.exports = {
    userCreate: require('./src/user.insert'),
    userTrigger: require('./src/users.trigger'),
    getUser: require('./src/user.get')
}