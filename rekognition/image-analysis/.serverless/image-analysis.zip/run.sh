# iniciando o projeto
sls

# iniciando o npm 
npm init - y

# instalando sdk aws
npm i aws-sdk